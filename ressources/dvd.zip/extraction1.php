<?php
/*
(c) Olivier N�pomiachty, F�vrier 2004
olivier.nepomiachty@developpez.com
*/
require ('connect.php');
require ('lib.php');
?>
<html>
<!-- Date de cr�ation: 10/08/2003 -->
<head>
<title></title>
<meta name="description" content="">
<meta name="keywords" content="">
<meta name="author" content="Olivier Nepomiachty">
<meta name="generator" content="WebExpert 5">
<link rel="StyleSheet" type="text/css" href="style1.css">
</head>
<body>
<form action="extraction2.php" method="post">
<?php
// initialisation
$no_films=0;

//$url="http://www.allocine.fr/recherche/default.html?motcle=conan%20le%20barbare";
//$url="http://www.allocine.fr/recherche/default.html?motcle=conan";

$handle = fopen ("liste_films.txt", "r");
while (!feof ($handle)) {
    $titre_recherche = trim(fgets($handle, 4096));
	if (!(ereg("^#", $titre_recherche)) && ($titre_recherche!='')) {
		$no_films++;
		$titre_recherche_url = urlencode($titre_recherche);
		$url="http://www.allocine.fr/recherche/default.html?motcle=$titre_recherche_url";
		
		$parametres=array('Referer'=>'', 'Proxy'=>'', 'BrowserName'=>'Mozilla/4.0 (compatible; MSIE 6.0;Windows NT 5.0)');
		$html = get_html($url,$parametres);
		$pos1 = strpos($html, "dans les titres de films d�j� sortis");
		if (!($pos1===FALSE)) {
			$pos2 = strpos($html,"</TABLE>",$pos1);
			if (!($pos2===FALSE)) {
				// il existe ou moins un r�sultat
				$data_brut = substr($html,$pos1,$pos2-$pos1);
				echo "<b>film n�$no_films : $titre_recherche</b><br>";
				$pos_ligne_1 = strpos($data_brut, "<TR><TD><LI>");
				$pos_ligne_2 = strpos($data_brut, "</TD></TR>",$pos_ligne_1);
				$nb_reponses=1;
				while ($pos_ligne_1 & $pos_ligne_2) {
					// le titre
					$ligne=substr($data_brut,$pos_ligne_1,$pos_ligne_2-$pos_ligne_1);
					$titre = trim(strip_tags($ligne));
					// url associ�e
					// $pos_url_1 : position du 1er guillemet de A HREF
					// $pos_url_2 : position du 2eme guillemet de A HREF
					if ($titre!='Plus...') {	
						$pos_url_1 = strpos($ligne, '<A HREF="');
						$pos_url_2 = strpos($ligne, '">', $pos_url_1);
						if ($pos_url_1 & $pos_url_2) {
							$pos_url_1+=strlen('<A HREF="');
							if ($ligne[$pos_url_1]=='/') $pos_url_1++; 
							$url = "http://www.allocine.fr/" . substr($ligne,$pos_url_1,$pos_url_2 - $pos_url_1);
							// on affiche le titre et on pr�-coche le premier bouton radio
							// l'utilisateur pourra cliquer sur le titre et ouvrir une nouvelle 
							// fen�tre avec la fiche du film
							$checked=($nb_reponses==1) ? "checked" : "";
							echo "<input type=\"radio\" name=\"film_$no_films\" value=\"$url\" $checked> <a href=\"$url\" target=\"_new\">$titre</a><br>\n";
						}
					}
					$nb_reponses++;
					$pos_ligne_1 = strpos($data_brut, "<TR><TD><LI>",$pos_ligne_2);
					$pos_ligne_2 = strpos($data_brut, "</TD></TR>",$pos_ligne_1);
				}
				echo "<input type=\"radio\" name=\"film_$no_films\" value=\"\"> supprimer ce film de la s�lection<br>\n";
			}
		}
		echo "<br>\n";
		
		// permet de flusher la sortie standard sur le navigateur
		// et ainsi d'afficher en l'�tat le contenu de la page
		echo str_pad(" ",300);
		echo "\n";
		ob_flush();
		flush();
		
	} 
}
fclose ($handle);

?>
<b>Format du r�sultat :</b><br>
<input type="radio" name="format_resultat" value="mysql" > insertion dans la base MySQL<br>
<input type="radio" name="format_resultat" value="xml"> fichier XML<br>
<input type="radio" name="format_resultat" value="html" checked> sortie html<br>
<br>
<input type="checkbox" name="mysql_delete" value="1"> vider les tables MySQL<br>
<input type="hidden" name="nb_films" value="<? echo $no_films; ?>">
<br>
<input type="submit" value="Continuer">
</form>
<br><br><br>
</body>
</html>