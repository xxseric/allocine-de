<?php
/*
(c) Olivier N�pomiachty, F�vrier 2004
olivier.nepomiachty@developpez.com
*/
Define("CONNEXION","curl");
//Define("CONNEXION","php");

Define("MYSQL",true);
//Define("MYSQL",false);

if (MYSQL) {
	// remplacer par vos valeurs de connexion
	$host="localhost";
	$user="user_db";
	$pwd="password";
	$base="DVD";
	$mysql_link = mysql_connect($host,$user,$pwd);
	mysql_select_db($base);
}
?>