<?php
/*
(c) Olivier N�pomiachty, F�vrier 2004
olivier.nepomiachty@developpez.com
*/
require ('connect.php');
require ('lib.php');
?>
<html>
<!-- Date de cr�ation: 02/02/2004 -->
<head>
<title></title>
<meta name="description" content="">
<meta name="keywords" content="">
<meta name="author" content="Olivier Nepomiachty">
<meta name="generator" content="WebExpert 5">
<link rel="StyleSheet" type="text/css" href="style1.css">
</head>
<body>
<b>Recherche simplifi�e de films dans la base de donn�es :</b><br>
<form method="post" action="resultat.php">
<table>
	<tr>
		<td>Titre de film</td>
		<td><input type="text" name="titre" size="40" maxlength="256"></td>
	</tr>
	<tr>
		<td>R�alisateur</td>
		<td>
			<select name="realisateur">
				<option value=""> Choisir____________________</option>
				<?php
				$sql = "SELECT * FROM REALISATEUR ORDER BY NOM_REALISATEUR";
				$result=mysql_query($sql);
				while ($row=mysql_fetch_object($result)) {
					echo "<option value=\"$row->ID_REALISATEUR\"> $row->NOM_REALISATEUR</option>\n";
				}
				?>
			</select>
		</td>
	</tr>
	<tr>
		<td>Acteur</td>
		<td>
			<select name="acteur">
				<option value=""> Choisir____________________</option>
				<?php
				$sql = "SELECT * FROM ACTEUR ORDER BY NOM_ACTEUR";
				$result=mysql_query($sql);
				while ($row=mysql_fetch_object($result)) {
					echo "<option value=\"$row->ID_ACTEUR\"> $row->NOM_ACTEUR</option>\n";
				}
				?>
			</select>
		</td>
	</tr>
	<tr>
		<td colspan="2"><input type="submit" value="rechercher"></td>
	</tr>
</table>
</form>

</body>
</html>