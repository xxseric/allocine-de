<?php
/*
(c) Olivier N�pomiachty, F�vrier 2004
olivier.nepomiachty@developpez.com
*/
require ('connect.php');
require ('lib.php');

// redirige sur la page d'appel si pas de param�tres
// (cas o� la page a �t� appel�e directement par erreur)
$nb_films=(int)$HTTP_POST_VARS['nb_films'];
if ($nb_films==0) {
	Header("Location: extraction1.php");
	exit();
}

// affiche l'ent�te de la page en fonction du format de sortie choisi
if ($HTTP_POST_VARS['format_resultat']=="xml")
	echo'<?xml version="1.0" encoding="ISO-8859-1"?>
	<LISTE_FILMS>';
else {
	echo '
	<html>
	<head>
	<title></title>
	<meta name="description" content="">
	<meta name="keywords" content="">
	<meta name="author" content="Olivier Nepomiachty">
	<meta name="generator" content="WebExpert 5">
	<link rel="StyleSheet" type="text/css" href="style1.css">
	</head>
	<body>
	';
	if (($HTTP_POST_VARS['format_resultat']=="mysql")&&($HTTP_POST_VARS['mysql_delete']=="1")) {
		mysql_query("DELETE FROM ACTEUR", $mysql_link);
		mysql_query("DELETE FROM ACTEUR_FILM", $mysql_link);
		mysql_query("DELETE FROM FILM", $mysql_link);
		mysql_query("DELETE FROM GENRE", $mysql_link);
		mysql_query("DELETE FROM GENRE_FILM", $mysql_link);
		mysql_query("DELETE FROM PAYS", $mysql_link);
		mysql_query("DELETE FROM REALISATEUR", $mysql_link);
	}
}

for ($i=1; $i<= $nb_films; $i++) {
	$success=false;
	
	// on passe un tableau associatif en param�tres de la fonction get_html
	// le code est ainsi facile � relire
	$parametres=array('Referer'=>'', 'Proxy'=>'', 'BrowserName'=>'Mozilla/4.0 (compatible; MSIE 6.0;Windows NT 5.0)');
	$url=$HTTP_POST_VARS["film_$i"];
	if ($url!='') {
		$html = get_html($url,$parametres);
		
		$pos1 = strpos($html, "<FONT Class=\"titrePage\">");
		$pos2 = strpos($html, "<FONT Class=link7>Synopsis</FONT>",$pos1);
		$data_brut = filtre_html(substr($html,$pos1,$pos2-$pos1));
		
		/* suite � cette manipulation $data_brut est de la forme :
		l0 : Jackie Brown
		l1 : Film am�ricain (1997). Policier, Drame. Dur�e : 2h 30mn. 
		l2 : Date de sortie : 01 Avril 1998
		l3 : Avec Pam Grier, Samuel L. Jackson, Robert De Niro, Bridget Fonda, Michael Keaton  Plus...
		l4 : R�alis� par Quentin Tarantino
		(etc)		
		*/
		$data=split("\n", $data_brut);
		$no_ligne=0;
		// ligne 0 : titre
		$titre = trim($data[$no_ligne]);
		
		// ligne 1 :
		$no_ligne++;
		list($pays, $genres, $duree) = split("\.", $data[$no_ligne]); 
		// $pays = "Film am�ricain (1997)"
		$pos1b=strpos_reverse($pays,'(', strlen($pays));
		$pos2b=strpos($pays,')',$pos1b); 
		$annee = trim(substr($pays,$pos1b+1,$pos2b-$pos1b-1));
		$pays=trim(substr($pays,0,$pos1b));
		// $genres : tableau
		// $genres = "Policier, Drame"
		$genres = explode(",",$genres);
		trim_tableau($genres);
		// $duree = "Dur�e : 2h 30mn";
		// convertie en minutes
		$duree = trim(str_replace("Dur�e : ","",$duree));
		$duree = hoursmin_to_minutes($duree);
		if ($duree==0) $duree=''; 

		// ligne 2 :
		// $date_de_sortie = "Date de sortie : 01 Avril 1998"
		// attention, cette ligne n'est pas obligatoire
		$no_ligne++;
		if (strpos($data[$no_ligne],'Date de sortie')===FALSE)
			$date_de_sortie = "";
		else {		 
			$date_de_sortie = trim(str_replace("Date de sortie : ","",$data[$no_ligne]));
			$no_ligne++;
		}

		// ligne 3 :
		// $acteurs : tableau 
		// $acteurs = "Avec Pam Grier, Samuel L. Jackson, Robert De Niro, Bridget Fonda, Michael Keaton  Plus...";
		$acteurs = trim(str_replace("Avec","",$data[$no_ligne]));
		$acteurs = trim(str_replace("Plus...","",$acteurs));
		$acteurs=explode(",",$acteurs);
		trim_tableau($acteurs);
		$no_ligne++;
		
		// ligne 4 :
		// $r�alisateur = "R�alis� par Quentin Tarantino"
		$realisateur = trim(str_replace("R�alis� par ","",$data[$no_ligne]));

		// extraction du synopsis
		// on reprend le fichier � partir de $pos2 (position du Synopsis)
		$pos1 = $pos2;
		$pos2 = strpos($html, "</FONT></DIV></TD></TR>",$pos1);
		$synopsis = filtre_html(substr($html,$pos1,$pos2-$pos1));
		$synopsis = trim(str_replace("Synopsis","",$synopsis));
		
		
		$film = array (
			'TITRE' => $titre, 
			'PAYS' => $pays, 
			'ANNEE' => $annee, 
			'GENRES' => $genres, 
			'DUREE' => $duree, 
			'DATE_DE_SORTIE' => $date_de_sortie, 
			'ACTEURS' => $acteurs, 
			'REALISATEUR' => $realisateur, 
			'SYNOPSIS' => $synopsis
		);
		
		if ($HTTP_POST_VARS['format_resultat']=="html") {
			echo genere_html_film($film)."<br>\n";
		}
		else if ($HTTP_POST_VARS['format_resultat']=="xml") {
			echo genere_xml_film($film);
		}
		else if ($HTTP_POST_VARS['format_resultat']=="mysql") {
			// ajout du film
			$id_film = existe_table($film['TITRE'], 'FILM', 'ID_FILM', 'TITRE');
			if ($id_film==0) {
				// ajout du pays
				$id_pays=insertion_table($film['PAYS'], 'PAYS', 'ID_PAYS', 'NOM_PAYS');
				// ajout du r�alisateur
				$id_realisateur=insertion_table($film['REALISATEUR'], 'REALISATEUR', 'ID_REALISATEUR', 'NOM_REALISATEUR');
				if ($film['ANNEE']!='') $film['ANNEE']=$film['ANNEE'].'-01-01';
				$sql="INSERT INTO FILM(TITRE, PAYS_ID, ANNEE, DUREE, DATE_SORTIE, REALISATEUR_ID, SYNOPSIS)
				VALUES('".addslashes($film['TITRE'])."', $id_pays, '".$film['ANNEE']."', '".$film['DUREE']."', 
				'".$film['DATE_DE_SORTIE']."', $id_realisateur, '".addslashes($film['SYNOPSIS'])."')";
				mysql_query($sql, $mysql_link);
				$id_film=mysql_insert_id($mysql_link);

				// ajout des acteurs
				foreach($film['ACTEURS'] as $acteur) {
				    $id_acteur=insertion_table($acteur, 'ACTEUR', 'ID_ACTEUR', 'NOM_ACTEUR');
					$sql="INSERT INTO ACTEUR_FILM(ACTEUR_ID,FILM_ID) VALUES($id_acteur, $id_film)";
					mysql_query($sql, $mysql_link);
				}

				// ajout des genres
				foreach($film['GENRES'] as $acteur) {
				    $id_genre=insertion_table($acteur, 'GENRE', 'ID_GENRE', 'NOM_GENRE');
					$sql="INSERT INTO GENRE_FILM(GENRE_ID,FILM_ID) VALUES($id_genre, $id_film)";
					mysql_query($sql, $mysql_link);
				}
				
				echo "<b>" . $film['TITRE'] . "</b> ajout� � la base<br>\n";
			}
			else
				echo "<b>" . $film['TITRE'] . "</b> est d�j� dans la base<br>\n";

			// permet de flusher la sortie standard sur le navigateur
			// et ainsi d'afficher en l'�tat le contenu de la page
			echo str_pad(" ",300);
			echo "\n";
			ob_flush();
			flush();

		}
	}		

}

if ($HTTP_POST_VARS['format_resultat']=="xml")
	echo '</LISTE_FILMS>';
else
	echo '
	<br><br><br>
	</body>
	</html>
	';
?>