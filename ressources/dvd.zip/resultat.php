<?php
/*
(c) Olivier N�pomiachty, F�vrier 2004
olivier.nepomiachty@developpez.com
*/
require ('connect.php');
require ('lib.php');
?>
<html>
<!-- Date de cr�ation: 02/02/2004 -->
<head>
<title></title>
<meta name="description" content="">
<meta name="keywords" content="">
<meta name="author" content="Olivier Nepomiachty">
<meta name="generator" content="WebExpert 5">
<link rel="StyleSheet" type="text/css" href="style1.css">
</head>
<body>
<b>R�sultats :</b><br>
<br>
<?php

$titre=$HTTP_POST_VARS['titre'];
$realisateur=(int)$HTTP_POST_VARS['realisateur'];
$acteur=(int)$HTTP_POST_VARS['acteur'];

$sql_from="";
$sql_where="";
if ($titre!='') $sql_where.=" AND FILM.TITRE LIKE '%$titre%' ";
if ($realisateur!=0) $sql_where.="AND ID_REALISATEUR=$realisateur ";
if ($acteur!=0) {
	$sql_from.=", ACTEUR_FILM";
	$sql_where.="AND ACTEUR_FILM.ACTEUR_ID=$acteur AND ACTEUR_FILM.FILM_ID=ID_FILM";
}

$sql = "
	SELECT FILM.*, NOM_PAYS, NOM_REALISATEUR
	FROM FILM, PAYS, REALISATEUR $sql_from
	WHERE PAYS_ID=ID_PAYS AND REALISATEUR_ID=ID_REALISATEUR $sql_where
	ORDER BY FILM.TITRE
";

$result=mysql_query($sql);
while ($row=mysql_fetch_object($result)) {
	echo "<b>Titre :</b> $row->TITRE<br>\n";
	echo "<b>Pays :</b> $row->NOM_PAYS<br>\n";
	echo "<b>Ann�e :</b> $row->ANNEE<br>\n";
	echo "<b>Dur�e :</b> $row->DUREE<br>\n";

	$sql="
		SELECT NOM_GENRE 
		FROM GENRE, GENRE_FILM 
		WHERE GENRE_ID=ID_GENRE AND FILM_ID=$row->ID_FILM";
	$result2=mysql_query($sql);
	$genres="";
	while ($row2=mysql_fetch_object($result2)) {
		$genres.="$row2->NOM_GENRE, ";
	}
	if ($genres!='') $genres=substr($genres,0,strlen($genres)-2).".";
	echo "<b>Genre :</b> $genres<br>\n";
		
	$sql="
		SELECT NOM_ACTEUR 
		FROM ACTEUR, ACTEUR_FILM 
		WHERE ACTEUR_ID=ID_ACTEUR AND FILM_ID=$row->ID_FILM";
	$result2=mysql_query($sql);
	$acteurs="";
	while ($row2=mysql_fetch_object($result2)) {
		$acteurs.="$row2->NOM_ACTEUR, ";
	}
	if ($acteurs!='') $acteurs=substr($acteurs,0,strlen($acteurs)-2).".";
	echo "<b>Acteurs :</b> $acteurs<br>\n";
		
	if ($row->DATE_SORTIE!='0000-00-00') echo "<b>Date sortie :</b> $row->DATE_SORTIE<br>\n";
	echo "<b>R�alisateur :</b> $row->NOM_REALISATEUR<br>\n";
	echo "<b>Synopsis :</b> $row->SYNOPSIS<br>\n";
	echo "<br>\n";
}
?>
<br>
<br>
<div align="center"><a href="recherche.php">Autre recherche</a></div><br>
<br>
<br>
&nbsp;
</body>
</html>