<?php
/*
(c) Olivier N�pomiachty, F�vrier 2004
olivier.nepomiachty@developpez.com
*/
function get_html($url, $parametres=array()) {
	if (CONNEXION=="curl") {
		$params='';
		if ($parametres['Referer']!="") $params.='-e '.$parametres['Referer'];
		if ($parametres['Proxy']!="") $params.='-x '.$parametres['Proxy'];
		if ($parametres['BrowserName']!="") $params.='-A "'.$parametres['BrowserName'].'"';
		return (`curl $params $url`);
	}
	else {
		if (strtoupper(substr($url,0,7))=="HTTP://") $url=substr($url,7);
		$p = strpos($url,"/");
		if ($p===FALSE) {
			$nom_domaine=$url;
			$get="/";
		}
		else {
			$nom_domaine=substr($url,0,$p);
			$get=substr($url,$p);
		}
		
		$errno=""; $errstr=""; $r="";
		$fp = fsockopen($nom_domaine, 80, &$errno, &$errstr, 15);
		if($fp) {
			socket_set_timeout($fp, 15);
			fputs($fp,"GET $get HTTP/1.1\r\n");
			fputs($fp,"Host:  $nom_domaine\r\n");
			fputs($fp,"Connection: Close\r\n\r\n");
			$r="";
			while(!feof($fp)) {
				$r.=fgets($fp,1024);
			}
			fclose($fp);
			return($r);
		}
		return('');
	}
}

function strpos_reverse($hack, $needle, $pos) {
	$needle_len=strlen($needle);
	$needle=strtoupper($needle);
	$c = $needle[0];
	while ($pos>0) {
		while (($hack[$pos]!=$c)&&($pos>0)) $pos--;
		if (pos==-1) return (false);
		if (strtoupper(substr($hack,$pos,$needle_len))==$needle) return($pos);
		$pos--;
	}	
	if (pos==-1) return (false);
}

function hoursmin_to_minutes($s) {
	// convertit une heure "2h 29mn" en minutes => 149
	$r=0;
	$s=trim($s);
	$pos1 = strpos($s, "h");
	if ((!$pos1===FALSE)) {
		$r=substr($s,0,$pos1);
		$r=((int)substr($s,0,$pos1)) * 60;
		$pos2 = strpos($s, "mn", $pos1);
		if ((!$pos2===FALSE)) {
			$r += (int)trim(substr($s,$pos1+1,$pos2-$pos1-1));
		}
	}
	return($r);
}

function trim_tableau(&$tab) {
	// effectue un trim sur chaque �l�ment du tableau
	for ($i=0; $i<count($tab); $i++) 
		$tab[$i] = trim(str_replace("&nbsp;", " ", $tab[$i])); 
}

function genere_xml_film($a) {
	$r = "<FILM>";
	foreach($a as $name => $val) {
		if (is_array($val)) {
			// lorsque $val est un array, $name se termine forc�ment par la lettre 's'
			// on la retire. Exemple : GENRES -> GENRE
			$name=substr($name,0,strlen($name)-1);
			foreach($val as $i) {
				$r .="<" . $name . ">";
				$r .= "$i";
				$r .="</" . $name . ">";
			}
		}
		else {
			$r .="<" . $name . ">";
			$r .= $val;
			$r .="</" . $name . ">";
		}
	}
	$r .= "</FILM>";
	return($r);
}

function genere_html_film($a) {
	$r = "<b>Titre :</b> " . $a['TITRE'] . "<br>\n";
	$r .= "<b>Pays :</b> " . $a['PAYS'] . "<br>\n";
	$r .= "<b>Ann�e :</b> " . $a['ANNEE'] . "<br>\n";
	$r .= "<b>Genres :</b> ";
		foreach($a['GENRES'] as $i)
			$r .= "$i, ";
		$r = substr($r, 0, strlen($r) - 2) . "<br>\n";
	$r .= "<b>Dur�e :</b> " . $a['DUREE'] . " minutes<br>\n";
	$r .= "<b>Date de sortie :</b> " . $a['DATE_DE_SORTIE'] . "<br>\n";
	$r .= "<b>Acteurs :</b> ";
		foreach($a['ACTEURS'] as $i)
			$r .= "$i, ";
		$r = substr($r, 0, strlen($r) - 2) . "<br>\n";
	$r .= "<b>R�alisateur :</b> " . $a['REALISATEUR'] . "<br>\n";
	$r .= "<b>Synopsis :</b> " . $a['SYNOPSIS'] . "<br>\n";
	return($r);	
}

function insertion_table($element, $table, $id_primaire_table, $nom_champ_element) {
	// insertion de l'�l�ment $element dans la table $table et renvoie son id
	// si l'�l�ment existe d�j�, retourne son id
	global $mysql_link;
	$element=trim($element);
	$sql = "SELECT $id_primaire_table FROM $table WHERE $nom_champ_element LIKE '$element'";
	$result = mysql_query($sql, $mysql_link);
	if (mysql_num_rows($result)==0) {
		mysql_free_result($result);
		$sql = "INSERT INTO $table($nom_champ_element) VALUES('$element')";
		mysql_query($sql, $mysql_link);
		$id_primaire_table = mysql_insert_id($mysql_link);
	}
	else {
		$row = mysql_fetch_row($result);
		$id_primaire_table = $row[0];
		mysql_free_result($result);
	}
	return($id_primaire_table);
}

function existe_table($element, $table, $id_primaire_table, $nom_champ_element) {
	// v�rifie l'existence de l'�l�ment $element dans la table $table et renvoie son id
	// si l'�l�ment n'existe pas, retourne 0
	global $mysql_link;
	$element=trim($element);
	$sql = "SELECT $id_primaire_table FROM $table WHERE $nom_champ_element LIKE '$element'";
	$result = mysql_query($sql, $mysql_link);
	if (mysql_num_rows($result)==0) {
		$id_primaire_table = 0;
	}
	else {
		$row = mysql_fetch_row($result);
		$id_primaire_table = $row[0];
		mysql_free_result($result);
	}
	return($id_primaire_table);
}

function filtre_html($s) {
	$s = str_replace("\r\n","",$s);
	$s = str_replace("\n","",$s);
	$s = str_replace("</TR>","</TR>\n",$s);
	$s = strip_tags($s);
	$s = str_replace("&nbsp;"," ",$s);
	return($s);
}

?>